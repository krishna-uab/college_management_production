<?php

namespace App\Http\Middleware;

use App\Models\SuperAdmin\Franchise;
use Carbon\Carbon;
use Closure;
use Illuminate\Http\Request;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;
use Symfony\Component\HttpFoundation\Response;

class CheckFranchisePlan
{

    public function handle(Request $request, Closure $next): Response
    {
        try {
            $payload = JWTAuth::parseToken()->getPayload();
        } catch (\Throwable $e) {
            return response()->json([
                'status'  => false,
                'message' => 'Unauthenticated. Please login again.',
            ], 401);
        }

        $type = (int) $payload->get('type');

        if ($type === 0) {
            return $next($request);
        }

        if (!in_array($type, [1, 2, 3, 4], true)) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid user type.',
            ], 403);
        }

        $franchiseId = $payload->get('franchise_id');

        $franchise = Franchise::find($franchiseId);

        if (!$franchise) {
            return response()->json([
                'status'  => false,
                'message' => 'Franchise not found. Please contact support.',
            ], 403);
        }

        if ($franchise->renewal_date) {

            $renewalDate = Carbon::parse($franchise->renewal_date);
            $gracePeriod = (int) ($franchise->grace_period ?? 0);

            $graceEndDate = $renewalDate
                ->copy()
                ->addDays($gracePeriod)
                ->endOfDay();

            if (now()->gt($graceEndDate)) {

                $message = match ($type) {
                    1 => 'Your plan has expired. Please renew your plan to continue.',
                    2 => 'Login blocked by service provider. Please contact your service provider.',
                    3, 4 => 'Your login has been denied. Please contact your school administrator.',
                    default => 'Portal access has been blocked. Please contact support.',
                };

                return response()->json([
                    'status'  => false,
                    'message' => $message,
                ], 403);
            }
        }

        return $next($request);
    }
}
